Jeff DiMarco
October 2014

This is a controller to take python modules as input "bot" players.

Run test.py to see an example!
