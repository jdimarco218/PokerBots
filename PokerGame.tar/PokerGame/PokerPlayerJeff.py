from PokerPlayer import PokerPlayer

class PokerPlayerJeff(PokerPlayer):
  
    def __init__(self, name):
        super(PokerPlayerJeff, self).__init__(name)
